# Ejecutar alarma virtual en EC2 y guardar en RDS MySQL

Esta configuración sirve para una demostración sin Raspberry física: EC2 genera lecturas periódicas de prueba, expone la API que consume Android y guarda en RDS. No representa medidas reales de sensores ni cumple una prueba física/serial.

## 1. Conectar la red EC2 → RDS

En EC2, abre la instancia y copia el ID de su grupo de seguridad (`sg-...`). En RDS > `database-1` > Conectividad y seguridad, abre el grupo de seguridad asociado y agrega una regla de entrada MySQL/TCP 3306 con origen igual al grupo de seguridad de la instancia EC2. No uses `0.0.0.0/0`. La instancia y RDS deben poder comunicarse por su VPC.

En RDS, copia el **endpoint**, el **puerto** y confirma el **nombre de la base de datos** y el usuario de MySQL. `database-1` es el identificador de la instancia RDS, no necesariamente el nombre del esquema.

## 2. Instalar el servicio en EC2

Conéctate por SSH a la instancia EC2 y ejecuta:

```bash
sudo apt update
sudo apt install -y python3-venv default-mysql-client curl
sudo mkdir -p /opt/alarma /var/lib/alarma
sudo chown -R "$USER":"$USER" /opt/alarma /var/lib/alarma
```

Copia `server.py` a `/opt/alarma/server.py`. Instala PyMySQL y descarga el certificado raíz de AWS para cifrar la conexión EC2-RDS:

```bash
python3 -m venv /opt/alarma/venv
/opt/alarma/venv/bin/pip install PyMySQL
sudo mkdir -p /etc/alarma/certs
sudo curl -fsS https://truststore.pki.rds.amazonaws.com/us-east-1/us-east-1-bundle.pem -o /etc/alarma/certs/rds-ca.pem
sudo chmod 644 /etc/alarma/certs/rds-ca.pem
```

AWS publica certificados y pasos de conexión TLS en su [guía oficial de SSL/TLS para RDS](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.SSL.html).

## 3. Configurar los secretos sin ponerlos en el código

Crea un archivo de entorno con permisos solo para administrador:

```bash
sudo nano /etc/alarma.env
```

Agrega y reemplaza todos los valores entre `< >`:

```ini
ALARM_HOST=0.0.0.0
ALARM_PORT=8000
ALARM_QUEUE_DB=/var/lib/alarma/queue.sqlite3
ALARM_TOKEN=<secreto-largo-aleatorio>
DEMO_MODE=true
GAS_THRESHOLD=500
SAMPLE_SECONDS=2
MYSQL_HOST=<endpoint-rds>
MYSQL_PORT=3306
MYSQL_DATABASE=<nombre-de-base>
MYSQL_USER=<usuario-mysql>
MYSQL_PASSWORD=<contraseña-mysql>
MYSQL_SSL_CA=/etc/alarma/certs/rds-ca.pem
```

Guarda con Ctrl+O, Enter y Ctrl+X. Protege el archivo:

```bash
sudo chmod 600 /etc/alarma.env
```

No incluyas ese archivo ni sus valores en Git ni en capturas públicas. El servidor crea la tabla `alarma_readings` al conectar si la base existe y el usuario tiene permiso para crear tablas.

## 4. Iniciar y verificar

Para una primera prueba en la sesión SSH:

```bash
sudo bash -c 'set -a; . /etc/alarma.env; set +a; exec /opt/alarma/venv/bin/python /opt/alarma/server.py'
```

En otra terminal de EC2 consulta la API:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/datos.json
```

Espera unos 20 segundos. Desde el cliente MySQL puedes comprobar que se insertaron lecturas:

```bash
mysql -h <endpoint-rds> -P 3306 -u <usuario-mysql> -p --ssl-ca=/etc/alarma/certs/rds-ca.pem <nombre-de-base>
```

Luego, en el prompt `mysql>`, ejecuta:

```sql
SELECT COUNT(*) FROM alarma_readings;
SELECT * FROM alarma_readings ORDER BY created_at DESC LIMIT 5;
```

El servicio guarda primero cada muestra en una cola SQLite local y trata de enviarla a RDS cada 15 segundos. Si RDS no está accesible, las muestras quedan pendientes y vuelve a intentar.

## 5. Arranque automático al reiniciar EC2

Detén la prueba anterior con Ctrl+C. Crea el servicio:

```bash
sudo nano /etc/systemd/system/alarma.service
```

Pega:

```ini
[Unit]
Description=API de alarma IoT virtual
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/alarma
EnvironmentFile=/etc/alarma.env
ExecStart=/opt/alarma/venv/bin/python /opt/alarma/server.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

Cambia `ubuntu` por el usuario real que muestra `whoami`. Después:

```bash
sudo chown -R ubuntu:ubuntu /var/lib/alarma
sudo systemctl daemon-reload
sudo systemctl enable --now alarma
sudo systemctl status alarma
```

Reemplaza `ubuntu` también en el comando `chown` si tu usuario es distinto.

## 6. Conectar Android

En el computador donde compilas Android, en `%USERPROFILE%\.gradle\gradle.properties`, establece:

```properties
alarmToken=<el-mismo-ALARM_TOKEN>
alarmBaseUrl=http://<IP-PUBLICA-EC2>:8000
```

La app debe apuntar al servidor EC2, no al endpoint MySQL. Sincroniza Gradle y crea el APK. Para una demo desde el teléfono, permite el puerto TCP 8000 en el grupo de seguridad EC2 solo desde la IP de acceso que corresponda. HTTP no cifra ese tramo; para cumplir seguridad, publica la API detrás de HTTPS con un dominio/certificado válido y limita el acceso. No guardes el token en un repositorio público.

Al abrir la app, las lecturas simuladas alternan entre nivel normal y alarma. El botón de ventilación envía comandos protegidos al servidor. Las lecturas se guardan en RDS, mientras que la Pi física, sensores, serial y consumo real se deben declarar como no demostrados porque este montaje es virtual.
