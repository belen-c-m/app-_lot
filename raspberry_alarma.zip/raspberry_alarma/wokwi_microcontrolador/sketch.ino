#include <Arduino.h>

// ESP32 virtual para probar lecturas, alarma y comandos por puerto serial.
// MQ2 AOUT -> GPIO34; boton de llama -> GPIO4; LED/ventilador -> GPIO2.
const int PIN_GAS = 34;
const int PIN_FLAME = 4;
const int PIN_FAN = 2;
const int GAS_THRESHOLD = 2200;

bool fanRequested = false;
unsigned long lastReport = 0;

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);
  pinMode(PIN_GAS, INPUT);
  pinMode(PIN_FLAME, INPUT_PULLUP);
  pinMode(PIN_FAN, OUTPUT);
  digitalWrite(PIN_FAN, LOW);
  Serial.println("Alarma IoT ESP32 virtual lista. Envia fan_on o fan_off.");
}

void processSerial() {
  if (!Serial.available()) return;
  String command = Serial.readStringUntil('\n');
  command.trim();
  if (command == "fan_on") {
    fanRequested = true;
    Serial.println("OK: ventilador solicitado encendido");
  } else if (command == "fan_off") {
    fanRequested = false;
    Serial.println("OK: ventilador solicitado apagado");
  } else if (command.length() > 0) {
    Serial.println("ERROR: usa fan_on o fan_off");
  }
}

void loop() {
  processSerial();

  int gas = analogRead(PIN_GAS);
  bool flame = digitalRead(PIN_FLAME) == LOW;
  bool alarm = gas >= GAS_THRESHOLD || flame;
  bool fan = fanRequested || alarm;
  digitalWrite(PIN_FAN, fan ? HIGH : LOW);

  if (millis() - lastReport >= 1000) {
    lastReport = millis();
    Serial.print("Gas: "); Serial.println(gas);
    Serial.print("Llama: "); Serial.println(flame ? "true" : "false");
    Serial.print("Ventilacion: "); Serial.println(fan ? "true" : "false");
    Serial.print("Alarma: "); Serial.println(alarm ? "ACTIVA" : "NORMAL");
    Serial.println("---");
  }
}