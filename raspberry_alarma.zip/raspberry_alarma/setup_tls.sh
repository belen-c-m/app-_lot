#!/usr/bin/env bash
set -euo pipefail
TLS_DIR="$HOME/alarma_tls"
SHARED_DIR="/mnt/alarma"
IP="$(hostname -I | awk '{print $1}')"
if ! command -v openssl >/dev/null 2>&1; then
  echo "Falta OpenSSL. Instálalo con: sudo apt install openssl -y" >&2
  exit 1
fi
if [[ -z "$IP" ]]; then echo "No pude detectar la IP de la Raspberry virtual." >&2; exit 1; fi
if [[ ! -d "$SHARED_DIR" || ! -w "$SHARED_DIR" ]]; then
  echo "No veo la carpeta compartida escribible en $SHARED_DIR." >&2
  exit 1
fi
mkdir -p "$TLS_DIR"
chmod 700 "$TLS_DIR"
openssl genrsa -out "$TLS_DIR/ca.key" 3072
openssl req -x509 -new -key "$TLS_DIR/ca.key" -sha256 -days 3650 \
  -out "$TLS_DIR/alarma_ca.crt" -subj "/CN=AlarmaIoT Demo Root CA" \
  -addext "basicConstraints=critical,CA:TRUE" \
  -addext "keyUsage=critical,keyCertSign,cRLSign" \
  -addext "subjectKeyIdentifier=hash"
openssl genrsa -out "$TLS_DIR/server.key" 2048
openssl req -new -key "$TLS_DIR/server.key" -out "$TLS_DIR/server.csr" -subj "/CN=$IP"
printf 'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=IP:%s\n' "$IP" > "$TLS_DIR/server.ext"
openssl x509 -req -in "$TLS_DIR/server.csr" -CA "$TLS_DIR/alarma_ca.crt" \
  -CAkey "$TLS_DIR/ca.key" -CAcreateserial -out "$TLS_DIR/server.crt" \
  -days 825 -sha256 -extfile "$TLS_DIR/server.ext"
chmod 600 "$TLS_DIR/ca.key" "$TLS_DIR/server.key"
cp "$TLS_DIR/alarma_ca.crt" "$SHARED_DIR/alarma_ca.crt"
echo "Certificados creados para IP $IP"
echo "Certificado privado del servidor: $TLS_DIR/server.crt"
echo "Clave privada del servidor: $TLS_DIR/server.key"
echo "Certificado CA público copiado a $SHARED_DIR/alarma_ca.crt"