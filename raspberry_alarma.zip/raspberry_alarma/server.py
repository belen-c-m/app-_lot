#!/usr/bin/env python3
"""API de alarma para EC2: sensores demo, cola SQLite y sincronización RDS MySQL."""
from __future__ import annotations
import json, os, sqlite3, ssl, threading, time, uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = os.getenv('ALARM_HOST', '0.0.0.0')
PORT = int(os.getenv('ALARM_PORT', '8000'))
QUEUE_DB = Path(os.getenv('ALARM_QUEUE_DB', '/var/lib/alarma/queue.sqlite3'))
TOKEN = os.getenv('ALARM_TOKEN', '')
THRESHOLD = int(os.getenv('GAS_THRESHOLD', '500'))
SAMPLE_SECONDS = float(os.getenv('SAMPLE_SECONDS', '2'))
DEMO_MODE = os.getenv('DEMO_MODE', 'true').lower() == 'true'
MYSQL_HOST = os.getenv('MYSQL_HOST', '')
MYSQL_PORT = int(os.getenv('MYSQL_PORT', '3306'))
MYSQL_DATABASE = os.getenv('MYSQL_DATABASE', '')
MYSQL_USER = os.getenv('MYSQL_USER', '')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '')
MYSQL_SSL_CA = os.getenv('MYSQL_SSL_CA', '')
TLS_CERT = os.getenv('ALARM_TLS_CERT', '')
TLS_KEY = os.getenv('ALARM_TLS_KEY', '')

lock = threading.RLock()
started = time.monotonic()
state = {'gas': 0, 'flame': False, 'fan': False, 'alarm': False,
         'mode': 'demo' if DEMO_MODE else 'hardware-not-configured', 'updated_at': None}
QUEUE_DB.parent.mkdir(parents=True, exist_ok=True)

@contextmanager
def queue_db():
    con = sqlite3.connect(QUEUE_DB, timeout=10)
    try:
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('CREATE TABLE IF NOT EXISTS readings (id INTEGER PRIMARY KEY, event_id TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL, gas INTEGER NOT NULL, flame INTEGER NOT NULL, fan INTEGER NOT NULL, synced INTEGER NOT NULL DEFAULT 0)')
        yield con
        con.commit()
    finally:
        con.close()

def mysql_connection():
    if not all((MYSQL_HOST, MYSQL_DATABASE, MYSQL_USER, MYSQL_PASSWORD)):
        raise RuntimeError('Configura MYSQL_HOST, MYSQL_DATABASE, MYSQL_USER y MYSQL_PASSWORD')
    try:
        import pymysql
    except ImportError as exc:
        raise RuntimeError('Falta PyMySQL: instálalo en el entorno virtual') from exc
    opts = dict(host=MYSQL_HOST, port=MYSQL_PORT, user=MYSQL_USER, password=MYSQL_PASSWORD,
                database=MYSQL_DATABASE, connect_timeout=4, read_timeout=5,
                write_timeout=5, autocommit=True, charset='utf8mb4')
    if MYSQL_SSL_CA:
        opts['ssl'] = {'ca': MYSQL_SSL_CA}
    return pymysql.connect(**opts)

def init_mysql():
    con = mysql_connection()
    try:
        with con.cursor() as cur:
            cur.execute('''CREATE TABLE IF NOT EXISTS alarma_readings (
                event_id CHAR(36) PRIMARY KEY,
                created_at VARCHAR(40) NOT NULL,
                gas INT NOT NULL,
                flame BOOLEAN NOT NULL,
                fan BOOLEAN NOT NULL,
                alarm BOOLEAN NOT NULL,
                INDEX idx_alarma_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4''')
    finally:
        con.close()

def save_sample(gas, flame, fan, alarm):
    created = datetime.now(timezone.utc).isoformat()
    event_id = str(uuid.uuid4())
    with queue_db() as con:
        con.execute('INSERT INTO readings(event_id,created_at,gas,flame,fan) VALUES(?,?,?,?,?)',
                    (event_id, created, gas, int(flame), int(fan)))
    with lock:
        state.update(gas=gas, flame=flame, fan=fan, alarm=alarm, updated_at=created)

def sensor_loop():
    # Demo repetible para EC2: nivel normal con pulsos de gas/llama para mostrar alertas.
    while True:
        elapsed = int(time.monotonic() - started)
        phase = elapsed % 40
        gas = 780 if 15 <= phase < 25 else 180
        flame = 20 <= phase < 23
        with lock:
            fan = state['fan']
            alarm = gas >= THRESHOLD or flame
            if alarm:
                fan = True
            created = datetime.now(timezone.utc).isoformat()
            state.update(gas=gas, flame=flame, fan=fan, alarm=alarm, updated_at=created)
        event_id = str(uuid.uuid4())
        with queue_db() as con:
            con.execute('INSERT INTO readings(event_id,created_at,gas,flame,fan) VALUES(?,?,?,?,?)',
                        (event_id, created, gas, int(flame), int(fan)))
        time.sleep(SAMPLE_SECONDS)

def sync_loop():
    while True:
        try:
            init_mysql()
            with queue_db() as q:
                rows = q.execute('SELECT id,event_id,created_at,gas,flame,fan FROM readings WHERE synced=0 ORDER BY id LIMIT 200').fetchall()
            if rows:
                con = mysql_connection()
                try:
                    with con.cursor() as cur:
                        cur.executemany('''INSERT IGNORE INTO alarma_readings
                            (event_id,created_at,gas,flame,fan,alarm) VALUES(%s,%s,%s,%s,%s,%s)''',
                            [(r[1],r[2],r[3],r[4],r[5],int(r[3] >= THRESHOLD or bool(r[4]))) for r in rows])
                    with queue_db() as q:
                        q.executemany('UPDATE readings SET synced=1 WHERE id=?', [(r[0],) for r in rows])
                finally:
                    con.close()
        except Exception as e:
            print(f'Sincronización RDS pendiente: {e}', flush=True)
        time.sleep(15)

class Handler(BaseHTTPRequestHandler):
    def respond(self, status, payload, content_type='application/json; charset=utf-8'):
        body = payload.encode('utf-8') if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body))); self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path == '/health':
            return self.respond(200, {'ok': True, 'mode': state['mode'], 'rds_configured': bool(MYSQL_HOST and MYSQL_DATABASE and MYSQL_USER)})
        if self.path == '/datos.json':
            with lock: s = dict(state)
            msg = ('Gas: {gas}\nLlama: {flame}\nVentilación: {fan}\nAlarma: {alarm}\n'
                   .format(gas=s['gas'], flame=str(bool(s['flame'])).lower(), fan=str(bool(s['fan'])).lower(),
                           alarm='ACTIVA' if s['alarm'] else 'NORMAL'))
            return self.respond(200, msg, 'text/plain; charset=utf-8')
        if self.path == '/api/v1/state':
            with lock: return self.respond(200, dict(state))
        return self.respond(404, {'error':'ruta no encontrada'})
    def do_POST(self):
        if not TOKEN or self.headers.get('Authorization') != 'Bearer ' + TOKEN:
            return self.respond(401, {'error':'no autorizado'})
        try:
            length = int(self.headers.get('Content-Length','0'))
            if length > 4096: return self.respond(413, {'error':'solicitud demasiado grande'})
            data = json.loads(self.rfile.read(length))
        except Exception: return self.respond(400, {'error':'JSON inválido'})
        if self.path != '/api/v1/command': return self.respond(404, {'error':'ruta no encontrada'})
        action = data.get('action')
        if action not in ('fan_on','fan_off'):
            return self.respond(400, {'error':'acción no permitida'})
        with lock:
            if action == 'fan_off' and state['alarm']:
                return self.respond(409, {'error':'alarma activa; ventilación bloqueada'})
            state['fan'] = action == 'fan_on'
            current = dict(state)
        return self.respond(200, {'ok':True,'state':current})
    def log_message(self, fmt, *args): print('%s %s' % (self.address_string(), fmt % args))

if __name__ == '__main__':
    if not TOKEN: raise SystemExit('Falta ALARM_TOKEN; configura un secreto antes de iniciar el servicio')
    if not DEMO_MODE: raise SystemExit('Este servidor usa DEMO_MODE=true; no hay sensores físicos configurados.')
    if bool(TLS_CERT) != bool(TLS_KEY): raise SystemExit('Configura ALARM_TLS_CERT y ALARM_TLS_KEY juntos')
    threading.Thread(target=sensor_loop, daemon=True).start()
    threading.Thread(target=sync_loop, daemon=True).start()
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    scheme = 'http'
    if TLS_CERT:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(TLS_CERT, TLS_KEY)
        httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
        scheme = 'https'
    print(f'Alarma {scheme.upper()} escuchando en {HOST}:{PORT}; sensores={state["mode"]}', flush=True)
    httpd.serve_forever()