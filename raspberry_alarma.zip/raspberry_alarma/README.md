# Sistema de alarma Raspberry Pi

## Lo que ya hace esta base

- Publica `/datos.json` en el formato de texto que consume la app entregada.
- Registra lecturas localmente en SQLite con cola de pendientes para sincronizar después.
- Ofrece estado JSON, confirmación de lecturas sincronizadas y comandos de ventilación.
- Exige token Bearer para todo comando o confirmación de sincronización.
- Arranca en modo demostración si no encuentra el hardware, para que puedas comprobar la conexión.

La app Android fuente ya está modificada para consultar `GET /datos.json`, enviar `POST /api/v1/command` y conservar un comando pendiente cuando se pierde la conexión. El servidor solo acepta acciones permitidas y requiere `Authorization: Bearer <token>`.

## Hardware sugerido

- Raspberry Pi 3/4/5 con fuente oficial adecuada y microSD de 16 GB o más.
- Sensor MQ-2 y conversor ADC MCP3008 (la Pi no tiene entrada analógica).
- Sensor de llama digital compatible con 3,3 V en GPIO17.
- Módulo de relé compatible con 3,3 V en GPIO27 y ventilador de baja tensión.
- Protoboard, cables, resistencia/pull-up según el módulo y alimentación separada para el ventilador.

MQ-2: VCC/GND según el módulo; salida analógica a CH0 del MCP3008. MCP3008: VDD y VREF a 3V3, AGND/DGND a GND, CLK a GPIO11, DOUT a GPIO9, DIN a GPIO10, CS a GPIO8. Sensor de llama OUT a GPIO17 y GND común. Entrada del relé a GPIO27. Verifica el pinout de tu placa y que ninguna señal exceda 3,3 V; no conectes cargas de red directamente a la Raspberry.

Los GPIO indicados son BCM. Cambia el pinout en `server.py` para los módulos reales. El umbral MQ-2 es orientativo y debe calibrarse; este prototipo educativo no reemplaza una alarma certificada ni debe usarse como sistema de seguridad de vida.

## Instalación en Raspberry Pi OS

```bash
sudo apt update
sudo apt install -y python3-venv
sudo raspi-config  # habilita SPI y reinicia
sudo mkdir -p /opt/alarma /var/lib/alarma
sudo cp server.py /opt/alarma/
sudo chown -R $USER:$USER /opt/alarma /var/lib/alarma
sudo chown -R pi:pi /var/lib/alarma  # usa el mismo usuario definido en systemd
python3 -m venv /opt/alarma/venv
/opt/alarma/venv/bin/pip install gpiozero
```

Para ejecutar y probar primero:

```bash
export ALARM_TOKEN='reemplaza-por-un-secreto-largo'
export GAS_THRESHOLD=500
sudo -E /opt/alarma/venv/bin/python /opt/alarma/server.py
```

En otra terminal de la Pi prueba `curl http://127.0.0.1:8000/health` y `curl http://127.0.0.1:8000/datos.json`. Averigua la IP actual de la Pi con `hostname -I`, configura `alarmBaseUrl` en las propiedades Gradle del usuario Android y reserva esa IP en el router.

## Arranque automático

Crea `/etc/systemd/system/alarma.service`:

```ini
[Unit]
Description=Backend de alarma IoT
After=network-online.target
Wants=network-online.target

[Service]
User=pi
WorkingDirectory=/opt/alarma
Environment=ALARM_HOST=0.0.0.0
Environment=ALARM_PORT=8000
Environment=ALARM_DB=/var/lib/alarma/alarma.sqlite3
Environment=ALARM_TOKEN=CAMBIA_ESTO_POR_UN_SECRETO_LARGO
Environment=GAS_THRESHOLD=500
ExecStart=/opt/alarma/venv/bin/python /opt/alarma/server.py
Restart=on-failure
RestartSec=3
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

Sustituye `pi` por el usuario real. Luego:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now alarma
sudo systemctl status alarma
```

## Seguridad y sincronización

El endpoint compatible `/datos.json` queda de solo lectura para conservar compatibilidad con la app. El servidor usa HTTP en la red local, que no cifra el tráfico: para una entrega con seguridad real, usa HTTPS con certificado confiable o una VPN entre el teléfono y la Raspberry, y no expongas el puerto 8000 a Internet. El token no debe quedar escrito en una app publicada; para una demostración, limita la red y usa un token temporal. La API deja las lecturas en cola (`/api/v1/pending`) y permite confirmarlas con `POST /api/v1/ack` y `{"ids":[...]}`. Falta configurar el destino externo (broker MQTT o base de datos) porque la guía no especifica credenciales ni servicio; la sincronización externa no está automatizada todavía.

## Qué presentar según la rúbrica

1. Video mostrando lectura de gas/llama, ventilación, desconexión y reconexión.
2. Evidencia de lecturas guardadas localmente durante una caída de red; para sincronización externa, configura el broker/base de datos y el consumidor de la cola.
3. Capturas de comandos Android y recepción de estado desde la Raspberry.
4. Prueba de token incorrecto (401), comando válido y protección que impide apagar ventilación durante alarma (409).
5. Tabla de consumo o duración de batería y medidas aplicadas (muestreo cada 2 s, pantalla/consulta solo cuando hace falta).
6. Plan de contingencia: conservar lecturas en SQLite, reconectar, alertar que el sistema está desconectado y arrancar en modo seguro.
7. Repositorio con código fuente Android y Raspberry. El inicio de sesión aún es de demostración con credenciales fijas; no uses contraseñas o datos personales reales.

## Integración con el código fuente Android

La carpeta Android entregada ya queda conectada con este servidor: la app consulta `/datos.json` cada 10 segundos mientras está abierta, aumenta el intervalo de reintento si pierde conexión (hasta 60 s), conserva la última lectura y encola un comando fallido. Al volver la conexión, reintenta el comando. Los botones de ventilación usan `POST /api/v1/command` y el mismo token del servidor. La lectura devuelve booleanos (`true`/`false`) para llama y ventilación.

Configura el token fuera del proyecto, en el archivo de propiedades Gradle de tu usuario de Windows: `%USERPROFILE%\.gradle\gradle.properties`:

```properties
alarmToken=usa-el-mismo-secreto-largo-que-en-la-raspberry
alarmBaseUrl=http://IP_ACTUAL_DE_LA_RASPBERRY:8000
```

Guarda exactamente el mismo valor en `ALARM_TOKEN` en el servicio de la Raspberry. No subas el secreto al repositorio. La URL debe ser la IP actual de la Pi. Luego sincroniza Gradle y recompila desde Android Studio.

El inicio de sesión Android sigue siendo una demostración con credenciales fijas en el código (`12345678-5` / `1234`); no sirve como autenticación real. No uses datos personales reales ni publiques esta app como producto.

El servidor de ejemplo usa HTTP. El token no cifra la conexión y puede ser capturado en una red compartida; úsalo solo para demostración en una red local controlada. Para una evaluación de seguridad real, habilita HTTPS con una CA confiable o lleva el tráfico por una VPN entre teléfono y Pi, y no abras el puerto 8000 a Internet. La clave también puede extraerse del APK; una solución de producción necesita identidad por dispositivo y credenciales revocables.



