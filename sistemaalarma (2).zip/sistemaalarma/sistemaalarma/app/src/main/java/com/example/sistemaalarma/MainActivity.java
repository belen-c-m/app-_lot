package com.example.sistemaalarma;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final String RASPBERRY_URL = BuildConfig.ALARM_BASE_URL;
    private static final String PREFS = "alarma_local";
    private static final long POLL_MS = 10_000;
    private TextView textUsuario, textEstadoSistema, textGas, textLlama, textVentilacion, textConexion;
    private boolean ventilacionActiva;
    private int gasActual;
    private boolean llamaActual;
    private boolean connected;
    private long retryMs = 2_000;
    private boolean destroyed;
    private boolean active;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!destroyed) conectarRaspberry(false);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        textUsuario = findViewById(R.id.textUsuario);
        textEstadoSistema = findViewById(R.id.textEstadoSistema);
        textGas = findViewById(R.id.textGas);
        textLlama = findViewById(R.id.textLlama);
        textVentilacion = findViewById(R.id.textVentilacion);
        textConexion = findViewById(R.id.textConexion);
        Button btnActualizar = findViewById(R.id.btnActualizar);
        Button btnSimular = findViewById(R.id.btnSimular);
        Button btnActivar = findViewById(R.id.btnActivar);
        Button btnDesactivar = findViewById(R.id.btnDesactivar);
        Button btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        String rut = getIntent().getStringExtra("rutUsuario");
        if (rut != null) textUsuario.setText("Usuario: " + rut);

        gasActual = prefs.getInt("gas", 0);
        llamaActual = prefs.getBoolean("llama", false);
        ventilacionActiva = prefs.getBoolean("ventilacion", false);
        actualizarInterfaz();
        textConexion.setText("Conexión IoT: RECUPERANDO ESTADO...");
        btnActualizar.setOnClickListener(v -> conectarRaspberry(true));
        btnSimular.setOnClickListener(v -> {
            gasActual = 2500; llamaActual = true; actualizarInterfaz();
            Toast.makeText(this, "Alerta simulada solo en pantalla", Toast.LENGTH_SHORT).show();
        });
        btnActivar.setOnClickListener(v -> enviarComando("fan_on"));
        btnDesactivar.setOnClickListener(v -> enviarComando("fan_off"));
        btnCerrarSesion.setOnClickListener(v -> {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    @Override protected void onStart() {
        super.onStart();
        active = true;
        handler.removeCallbacks(poll);
        handler.post(poll);
    }

    @Override protected void onStop() {
        active = false;
        handler.removeCallbacks(poll);
        super.onStop();
    }

    private void conectarRaspberry(boolean manual) {
        textConexion.setText("Conexión IoT: CONECTANDO...");
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(RASPBERRY_URL + "/datos.json").openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(4000); c.setReadTimeout(4000);
                c.setUseCaches(false); c.setRequestProperty("Accept", "text/plain");
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) throw new Exception("HTTP " + c.getResponseCode());
                BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder body = new StringBuilder(); String line;
                while ((line = reader.readLine()) != null) body.append(line).append('\n');
                reader.close(); procesarDatosRaspberry(body.toString());
                enviarPendienteSiExiste();
                connected = true; retryMs = 2_000;
                handler.post(() -> textConexion.setText("Conexión IoT: RASPBERRY CONECTADA"));
                programarSiguiente(POLL_MS);
            } catch (Exception e) {
                connected = false;
                handler.post(() -> textConexion.setText("Conexión IoT: SIN CONEXIÓN; reintentando"));
                long delay = retryMs; retryMs = Math.min(retryMs * 2, 60_000);
                programarSiguiente(delay);
                if (manual) handler.post(() -> Toast.makeText(this, "No se pudo conectar; se reintentará automáticamente", Toast.LENGTH_SHORT).show());
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private void procesarDatosRaspberry(String datos) throws Exception {
        Integer gas = null; Boolean flame = null, fan = null;
        for (String raw : datos.split("\\r?\\n")) {
            String[] pair = raw.split(":", 2); if (pair.length != 2) continue;
            String key = pair[0].trim().toLowerCase(); String value = pair[1].trim().toLowerCase();
            if (key.equals("gas")) gas = Integer.parseInt(value);
            else if (key.equals("llama")) flame = value.equals("true") || value.equals("detectada") || value.equals("1");
            else if (key.equals("ventilación") || key.equals("ventilacion")) fan = value.equals("true") || value.equals("encendida") || value.equals("1");
        }
        if (gas == null || flame == null || fan == null) throw new Exception("Respuesta incompleta");
        final int g = gas; final boolean f = flame, v = fan;
        prefs.edit().putInt("gas", g).putBoolean("llama", f).putBoolean("ventilacion", v).apply();
        handler.post(() -> { gasActual = g; llamaActual = f; ventilacionActiva = v; actualizarInterfaz(); });
    }

    private void enviarComando(String action) {
        if (BuildConfig.ALARM_TOKEN.isEmpty()) {
            Toast.makeText(this, "Configura alarmToken en Gradle para habilitar comandos", Toast.LENGTH_LONG).show(); return;
        }
        executor.execute(() -> {
            try { postCommand(action); handler.post(() -> Toast.makeText(this, "Comando enviado a Raspberry", Toast.LENGTH_SHORT).show()); conectarRaspberry(false); }
            catch (Exception e) {
                prefs.edit().putString("pending_command", action).apply();
                handler.post(() -> Toast.makeText(this, "Sin conexión: comando guardado para reintentar", Toast.LENGTH_LONG).show());
                if (!destroyed) conectarRaspberry(false);
            }
        });
    }

    private void enviarPendienteSiExiste() {
        String action = prefs.getString("pending_command", null);
        if (action == null || BuildConfig.ALARM_TOKEN.isEmpty()) return;
        try { postCommand(action); prefs.edit().remove("pending_command").apply(); }
        catch (Exception ignored) { /* Se conserva para el próximo intento de conexión. */ }
    }

    private void postCommand(String action) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(RASPBERRY_URL + "/api/v1/command").openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(4000); c.setReadTimeout(4000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Authorization", "Bearer " + BuildConfig.ALARM_TOKEN);
            byte[] payload = ("{\"action\":\"" + action + "\"}").getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(payload.length);
            try (OutputStream out = c.getOutputStream()) { out.write(payload); }
            int status = c.getResponseCode();
            if (status < 200 || status >= 300) throw new Exception("Comando rechazado HTTP " + status);
        } finally { if (c != null) c.disconnect(); }
    }

    private void programarSiguiente(long delay) {
        handler.removeCallbacks(poll); if (active && !destroyed) handler.postDelayed(poll, delay);
    }

    private void actualizarInterfaz() {
        textGas.setText("Gas / Humo: " + gasActual);
        textLlama.setText(llamaActual ? "LLAMA DETECTADA" : "Llama: NO DETECTADA");
        boolean alerta = gasActual >= 500 || llamaActual;
        textEstadoSistema.setText(alerta ? "ALERTA DETECTADA" : "SISTEMA NORMAL");
        textEstadoSistema.setTextColor(getResources().getColor(alerta ? android.R.color.holo_red_dark : android.R.color.holo_green_dark));
        textVentilacion.setText(ventilacionActiva ? "Ventilación: ENCENDIDA" : "Ventilación: APAGADA");
    }

    @Override protected void onDestroy() {
        destroyed = true; handler.removeCallbacksAndMessages(null); executor.shutdownNow(); super.onDestroy();
    }
}







