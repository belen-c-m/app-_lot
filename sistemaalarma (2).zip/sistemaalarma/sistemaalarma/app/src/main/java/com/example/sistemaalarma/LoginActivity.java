package com.example.sistemaalarma;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editRut;
    private EditText editPassword;
    private Button btnIngresar;
    private TextView textError;

    // Credenciales de demostración
    private final String RUT_DEMO = "12345678-5";
    private final String PASSWORD_DEMO = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editRut = findViewById(R.id.editRut);
        editPassword = findViewById(R.id.editPassword);
        btnIngresar = findViewById(R.id.btnIngresar);
        textError = findViewById(R.id.textError);

        editPassword.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        btnIngresar.setOnClickListener(v -> iniciarSesion());
    }

    private void iniciarSesion() {

        String rut = editRut.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (rut.isEmpty() || password.isEmpty()) {
            textError.setText("Complete todos los campos.");
            return;
        }

        if (rut.equals(RUT_DEMO) && password.equals(PASSWORD_DEMO)) {

            Toast.makeText(
                    LoginActivity.this,
                    "Inicio de sesión correcto",
                    Toast.LENGTH_SHORT
            ).show();

            Intent intent = new Intent(
                    LoginActivity.this,
                    MainActivity.class
            );

            intent.putExtra("rutUsuario", rut);

            startActivity(intent);
            finish();

        } else {

            textError.setText(
                    "RUT o contraseña incorrectos."
            );
        }
    }
}