plugins {
    alias(libs.plugins.android.application)
}

val alarmToken = providers.gradleProperty("alarmToken").orElse("").get()
val alarmBaseUrl = providers.gradleProperty("alarmBaseUrl").orElse("http://10.227.83.130:8000").get()

android {
    namespace = "com.example.sistemaalarma"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.sistemaalarma"
        minSdk = 24
        targetSdk = 37
        versionCode = 2
        versionName = "1.1"
        buildConfigField("String", "ALARM_TOKEN", "\"$alarmToken\"")
        buildConfigField("String", "ALARM_BASE_URL", "\"$alarmBaseUrl\"")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release {
            optimization { enable = false }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}

